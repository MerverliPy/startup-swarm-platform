import TaskForm from "@/components/task-form";
import { listSwarmRuns } from "@/lib/api";
import { canUseCopilot } from "@/lib/copilot";

export default async function DashboardPage() {
  const runs = await listSwarmRuns().catch(() => []);
  const copilotEnabled = canUseCopilot();

  return (
    <main style={{ display: "grid", gap: 24 }}>
      <h2>Dashboard</h2>
      <section>
        <h3>Create run</h3>
        <TaskForm />
      </section>

      <section>
        <h3>Copilot integration</h3>
        <p>{copilotEnabled ? "Enabled in environment" : "Disabled in environment"}</p>
        <p>
          This starter expects server-side Copilot calls using the signed-in user's GitHub token.
        </p>
      </section>

      <section>
        <h3>Recent runs</h3>
        <pre style={{ overflowX: "auto", background: "#111", color: "#eee", padding: 16 }}>
          {JSON.stringify(runs, null, 2)}
        </pre>
      </section>
    </main>
  );
}
